import { createContext } from "react";

export const AuthenticationContext = createContext();

export default AuthenticationContext;
